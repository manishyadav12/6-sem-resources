 <footer>
            <p>Client Management System @ 2021 by CampCodes</p>
        </footer>